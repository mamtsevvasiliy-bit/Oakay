rootProject.name = "OakayContracts"
include(":app")
