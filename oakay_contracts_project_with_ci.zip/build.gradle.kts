plugins {
    // no-op, actual plugins are in app module
}

task("hello") {
    doLast {
        println("OakayContracts root")
    }
}
